<html>
    <head>
        <title>
            Mein erstes Formular
        </title>
    </head>
    <body>
        <form method="post" action="/abgesendet">
            <?php echo csrf_field(); ?>
            <input type="text" name="name" placeholder="Name" /><br>
            <input type="text" name="firstname" placeholder = "Vorname"/><br>
            <input type="email" name="email" placeholder="E-Mail"/><br>
            <input type="password" name="password" placeholder="Passwort"/><br>
            <input type="submit" label="Absenden"/>
        </form>
    </body>
</html><?php /**PATH C:\xampp\htdocs\beispiel\resources\views/welcome.blade.php ENDPATH**/ ?>