<html>
    <head>
        <title>
            Mein erstes Formular
        </title>
    </head>
    <body>
        Hallo <?php echo e($name); ?> <?php echo e($firstname); ?>.
    </body>
</html><?php /**PATH C:\xampp\htdocs\beispiel\resources\views/ausgabe.blade.php ENDPATH**/ ?>