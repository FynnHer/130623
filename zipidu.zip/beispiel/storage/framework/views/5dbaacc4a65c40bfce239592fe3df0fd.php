<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Der Blog</title>
</head>

<body>

    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h1><?php echo e($blog->ueberschrift); ?></h1>

        <p><?php echo e($blog->blogeintrag); ?></p>

        <p>Geschrieben von <?php echo e($blog->autor); ?> am <?php echo e($blog->datum); ?>.</p>
        <p>-------------------------------------------------------------------------------------------------------</p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\beispiel\resources\views/bloganzeige.blade.php ENDPATH**/ ?>