<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class beispiel extends Controller
{
    //
    public function verarbeiten(Request $request){
        return view('ausgabe',[
            'name' => $request['name'],
            'firstname' => $request['firstname'],
        ]);
    }
}
