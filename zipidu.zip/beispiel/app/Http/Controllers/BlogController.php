<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Blog;
use Illuminate\Contracts\View\View;

class BlogController extends Controller
{
    //

    public function store(Request $request){
        $blog = new Blog();
        $blog->ueberschrift = $request['ueberschrift'];
        $blog->datum = $request['datum'];
        $blog->autor = $request['autor'];
        $blog->blogeintrag = $request['Blogeintrag'];
        $blog->save();
    }

    public function index(){
        $blogs = Blog::all();
        return view('bloganzeige', [
            'blogs' => $blogs,
        ]);
    }

}
