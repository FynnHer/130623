<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Der Blog</title>
</head>

<body>

    @foreach ($blogs as $blog)
        <h1>{{ $blog->ueberschrift }}</h1>

        <p>{{ $blog->blogeintrag }}</p>

        <p>Geschrieben von {{ $blog->autor }} am {{ $blog->datum }}.</p>
        <p>-------------------------------------------------------------------------------------------------------</p>
    @endforeach

</body>

</html>
