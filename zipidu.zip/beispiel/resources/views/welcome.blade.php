<html>
    <head>
        <title>
            Mein erstes Formular
        </title>
    </head>
    <body>
        <form method="post" action="/abgesendet">
            @csrf
            <input type="text" name="name" placeholder="Name" /><br>
            <input type="text" name="firstname" placeholder = "Vorname"/><br>
            <input type="email" name="email" placeholder="E-Mail"/><br>
            <input type="password" name="password" placeholder="Passwort"/><br>
            <input type="submit" label="Absenden"/>
        </form>
    </body>
</html>