<html>

<head>
    <title>
        Mein erstes Formular
    </title>
</head>

<body>
    <form method="post" action="/bloganzeige">
        @csrf
        <input type="text" name="ueberschrift" placeholder="Überschrift" /><br>
        <input type="text" name="autor" placeholder="Autor" /><br>
        <input type="text" name="datum" placeholder="Datum" /><br>
        <textarea rows="10" cols="50" name="Blogeintrag"></textarea><br>


        <input type="submit" label="Absenden" />
    </form>
</body>

</html>
