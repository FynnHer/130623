<html>
    <head>
        <title>
            Mein erstes Formular
        </title>
    </head>
    <body>
        Hallo {{$name}} {{$firstname}}.
    </body>
</html>